/* author : Salah yousef muhammad. 
   Project Details : simple application that performs statistical analytics on a dataset. 
*/
