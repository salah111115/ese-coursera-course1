/******************************************************************************

 * Copyright (C) 2017 by Alex Fosdick - University of Colorado

 *

 * Redistribution, modification or use of this software in source or binary

 * forms is permitted as long as the files maintain this copyright. Users are 

 * permitted to modify this and use it to learn about the field of embedded

 * software. Alex Fosdick and the University of Colorado are not liable for any

 * misuse of this material. 

 *

 *****************************************************************************/

/**

 * @file <stats.h> 

 * @brief <header file contains function prototypes.>

 *

 * <Add Extended Description Here>

 *

 * @author <Salah Yousef Muhammad>

 * @date <16 oct 2017 >

 *

 */

#ifndef __STATS_H__

#define __STATS_H__



/* Add Your Declarations and Function Comments here */ 



/**

 * @brief <This function print the statistic values on the screen.>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to an array that hold the data to perform statistics calculations on them.>

 * @param <size> <array size.>

 *

 * @return <void, no return data>

 */



void print_statistics(unsigned char *arr_ptr, int size);







/**

 * @brief <This function print array to the screen>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <void, no return data>

 */

void print_array(unsigned char *arr_ptr, int size);







/**

 * @brief <this function calculate the median of ann array>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <median value of the array>

 */

unsigned char find_median(unsigned char *arr_ptr, int size);







/**

 * @brief <this function calculate the mean of ann array>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <mean value of the array>

 */

unsigned char find_mean(unsigned char *arr_ptr, int size);







/**

 * @brief <this function calculate the maximum of ann array>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <Maximum value in the array>

 */

unsigned char find_maximum(unsigned char *arr_ptr, int size);







/**

 * @brief <this function calculate the minimum of ann array>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <Minimum value in the array>

 */

unsigned char find_minimum(unsigned char *arr_ptr, int size);







/**

 * @brief <this function sorts array form biggest element to the smallest one.>

 *

 * <Add Extended Description Here>

 *

 * @param <arr_ptr> <pointer to hold the array address>

 * @param <size> <array size.>

 *

 * @return <void, no return data>

 */

void sort_array(unsigned char *arr_ptr, int size);







/**

 * @brief <this function swap two chars>

 *

 * <Add Extended Description Here>

 *

 * @param <x> <pointer to char 1.>

 * @param <y> <pointer to char 2.>

 *

 * @return <void, no return data>

 */

void swap(unsigned char *x , unsigned char *y);

#endif /* __STATS_H__ */

