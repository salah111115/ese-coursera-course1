/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file <stats.c> 
 * @brief <Program to analyze an array of unsigned char data items and report analytics on the maximum, minimum, mean,
      and median of the data set. In addition, reordering this data set from large to small. >
 *
 * <All statistics are rounded down to the nearest integer. After analysis and sorting is done,
      data is printed to the screen in nicely formatted presentation>
 *
 * @author <Salah Yousef Muhammad>
 * @date <16 oct 2017 >
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

   
    
  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */
      print_statistics(test, SIZE);
      sort_array(test, SIZE);
      print_array(test, SIZE);
}

/* Add other Implementation File Code Here */
void print_statistics(unsigned char *arr_ptr, int size){
	

	unsigned char minimum = find_minimum (arr_ptr,size);
    printf("minimum=%i\n",minimum );

    unsigned char maximum = find_maximum (arr_ptr,size);
    printf("maximum=%i\n",maximum );

    int medianNum = find_median(arr_ptr,size);
    printf("medianNumber =%i\n",medianNum );

    int meanNum = find_mean(arr_ptr,size);
    printf("meanNumber =%i\n",meanNum );

    
}
void print_array(unsigned char *arr_ptr, int size){
	for (int i = 0; i < size; ++i)
	{
		printf("OurArrayData[%i]=%i\n",i,arr_ptr[i]);
	}
}
unsigned char find_median(unsigned char *arr_ptr, int size){
	sort_array(arr_ptr,size);
	int first_num,second_num;
	if ((size % 2) == 0)
	{
		first_num = (size/2)-1;
		second_num = first_num + 1;
		return ((arr_ptr[first_num]+arr_ptr[second_num])/2);

	}
	else{
		return (arr_ptr[(size/2)]);
	}
}
unsigned char find_mean(unsigned char *arr_ptr, int size){
	int sum = 0;
	for (int i = 0; i < size; ++i)
	{
		sum = sum + arr_ptr[i];
	}
	return ((sum)/(size));
}
unsigned char find_maximum(unsigned char *arr_ptr, int size){
	unsigned char buff = arr_ptr[0];
	unsigned char x;
	for (int i = 1; i < size; ++i)
	{
		x = arr_ptr[i];
		if (buff<arr_ptr[i])
		{
			swap(&buff,&x);
		}
	}
	return buff;
}
unsigned char find_minimum(unsigned char *arr_ptr, int size){
	unsigned char buff = arr_ptr[0];
	unsigned char x;
	for (int i = 1; i < size; ++i)
	{
		x = arr_ptr[i];
		if (buff>arr_ptr[i])
		{
			swap(&buff,&x);
		}
	}
	return buff;

}
void sort_array(unsigned char *arr_ptr, int size){
	for (int i = 0; i < size; ++i)
	{
		for (int j = i+1; j < size; ++j)
		{
			if(arr_ptr[i]<arr_ptr[j]){
				swap(&arr_ptr[i],&arr_ptr[j]);
			}
		}
	}
}
void swap(unsigned char *x , unsigned char *y){
	*x = *x + *y;
	*y = *x - *y;
	*x = *x - *y;
}
